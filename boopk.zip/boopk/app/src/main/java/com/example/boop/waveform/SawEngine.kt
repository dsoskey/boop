package com.example.boop.waveform

class SawEngine: WaveformEngine {
    override fun getWaveform(frequency: Double): () -> DoubleArray {
        return fun (): DoubleArray {
            val duration = DEFAULT_SAMPLE_RATE_IN_SECONDS / frequency
            val mSound = DoubleArray(duration.toInt())
            for (i in mSound.indices) {
                mSound[i] = frequency % i
            }
            return mSound
        }
    }
}
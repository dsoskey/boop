package com.example.boop

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import com.example.boop.pad.*
import com.example.boop.synth.DefaultSynthesizer
import com.example.boop.synth.Synthesizer
import com.jaredrummler.android.colorpicker.ColorPickerDialogListener
import java.util.HashMap

class MainActivity : FragmentActivity(), ColorPickerDialogListener, ColorSchemeManager {

    override var colorScheme: ColorScheme = ColorScheme.PIANO(Color.valueOf(Color.parseColor("#f166ff")), Color.valueOf(Color.parseColor("#ffa40c")))
    private var buttonToColor: MutableMap<Int, Int>? = null
    private val synthesizer: Synthesizer = DefaultSynthesizer.DEFAULT_SYNTHESIZER
    private val padFragment: PadFragment = PadFragment(synthesizer)

    override fun onDialogDismissed(dialogId: Int) {}
    override fun onColorSelected(dialogId: Int, color: Int) {
        val originalColor = Color.valueOf(buttonToColor!![dialogId]!!)
        val newColor = Color.valueOf(color)
        val buttonIds = colorScheme.popColorMap(originalColor)
        colorScheme = colorScheme.withColorMap(newColor, buttonIds)
        buttonToColor!![dialogId] = color
        padFragment.setPadColors(colorScheme)
    }

    override fun onColorSchemeChange(newScheme: ColorScheme) {
        colorScheme = newScheme
        padFragment.setPadColors(colorScheme)
    }

    private fun configureColorMappings() {
        buttonToColor = HashMap()
        if (colorScheme.colors.size == 2) {
            val colors = colorScheme.colors.iterator()
            val color1 = colors.next()
            buttonToColor!![R.id.colorpicker1] = color1.toArgb()
            val color2 = colors.next()
            buttonToColor!![R.id.colorpicker2] = color2.toArgb()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        configureColorMappings()

        val synthesizer = DefaultSynthesizer.DEFAULT_SYNTHESIZER

        // Adding a fragment to a view

        val engineTransaction = supportFragmentManager.beginTransaction()
        val engineSelectorFragment = EngineSelectorFragment(synthesizer)
        engineTransaction.add(R.id.side_action, engineSelectorFragment)
        engineTransaction.commit()

        val colorPickerTransaction = supportFragmentManager.beginTransaction()
        val padColorSelector = PadColorSelector(this, buttonToColor!!)
        colorPickerTransaction.add(R.id.color_picker, padColorSelector)
        colorPickerTransaction.commit()

        val patternPickerTransaction = supportFragmentManager.beginTransaction()
        val padPatternSelector = PadPatternSelector(this, buttonToColor!!)
        patternPickerTransaction.add(R.id.pattern_picker, padPatternSelector)
        patternPickerTransaction.commit()

        val fragmentTransaction = supportFragmentManager.beginTransaction()
        fragmentTransaction.add(R.id.main_action, padFragment)
        fragmentTransaction.commit()
    }
}
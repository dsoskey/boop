package com.example.boop

import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import com.example.boop.synth.Synthesizer
import com.example.boop.waveform.SineEngine
import com.example.boop.waveform.SquareEngine

class EngineSelectorFragment(private val synthesizer: Synthesizer) : Fragment(), View.OnTouchListener {

    private var fragmentView: View? = null

    override fun onTouch(view: View, event: MotionEvent): Boolean {
        val squareButton = fragmentView!!.findViewById<Button>(R.id.square_button)
        val sineButton = fragmentView!!.findViewById<Button>(R.id.sine_button)
        when (view.id) {
            R.id.square_button -> {
                squareButton.setTextColor(Color.parseColor("#FFFFFF"))
                sineButton.setTextColor(Color.parseColor("#000000"))
                synthesizer.waveformEngine = SquareEngine()
            }
            R.id.sine_button -> {
                sineButton.setTextColor(Color.parseColor("#FFFFFF"))
                squareButton.setTextColor(Color.parseColor("#000000"))
                synthesizer.waveformEngine = SineEngine()
            }
        }
        return true
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saveInstanceState: Bundle?): View? {
        fragmentView = inflater.inflate(R.layout.engine_handler, container, false)
        return fragmentView
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        configureButtons()
    }

    private fun configureButtons() {
        val squareButton = fragmentView!!.findViewById<Button>(R.id.square_button)
        squareButton.setOnTouchListener(this)

        val sineButton = fragmentView!!.findViewById<Button>(R.id.sine_button)
        sineButton.setOnTouchListener(this)
        sineButton.setTextColor(Color.parseColor("#FFFFFF"))
    }
}